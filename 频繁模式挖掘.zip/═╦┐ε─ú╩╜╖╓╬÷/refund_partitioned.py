import argparse
import json
from pyspark.sql import SparkSession
from pyspark.sql.functions import (
    col, from_json, explode, collect_set,
    sha2, concat_ws, size, hash, abs
)
from pyspark.sql.types import StructType, StructField, ArrayType, StringType, IntegerType, DoubleType

parser = argparse.ArgumentParser()
parser.add_argument("--partition_id", type=int, required=True)
parser.add_argument("--num_partitions", type=int, default=6)
args = parser.parse_args()

# 初始化 Spark
spark = SparkSession.builder \
    .appName(f"Refund_Transactions_Part_{args.partition_id}") \
    .config("spark.driver.memory", "16g") \
    .config("spark.executor.memory", "24g") \
    .getOrCreate()
spark.sparkContext.setLogLevel("ERROR")

# 主类别映射
main_map = {
    "电子产品": ["智能手机", "笔记本电脑", "平板电脑", "智能手表", "耳机", "音响", "相机", "摄像机", "游戏机"],
    "服装": ["上衣", "裤子", "裙子", "内衣", "鞋子", "帽子", "手套", "围巾", "外套"],
    "食品": ["零食", "饮料", "调味品", "米面", "水产", "肉类", "蛋奶", "水果", "蔬菜"],
    "家居": ["家具", "床上用品", "厨具", "卫浴用品"],
    "办公": ["文具", "办公用品"],
    "运动户外": ["健身器材", "户外装备"],
    "玩具": ["玩具", "模型", "益智玩具"],
    "母婴": ["婴儿用品", "儿童课外读物"],
    "汽车用品": ["车载电子", "汽车装饰"]
}
sub2main = [(sub, main) for main, subs in main_map.items() for sub in subs]

# 商品目录映射
with open("E:/master/data_mining/数据探索性分析与预处理/product_catalog.json", "r", encoding="utf-8") as f:
    catalog = {str(p["id"]): p["category"] for p in json.load(f)["products"]}
catalog_df = spark.createDataFrame([(k, v) for k, v in catalog.items()], ["item_id_str", "subcategory"])
subcat_df = spark.createDataFrame(sub2main, ["subcategory", "main_category"])

# JSON 结构定义
purchase_schema = StructType([
    StructField("avg_price", DoubleType(), True),
    StructField("categories", StringType(), True),
    StructField("items", ArrayType(StructType([
        StructField("id", IntegerType(), True)
    ])), True),
    StructField("payment_method", StringType(), True),
    StructField("payment_status", StringType(), True),
    StructField("purchase_date", StringType(), True),
])

df = spark.read.parquet("E:/master/data_mining/30G_data_new/30G_data_new")

parsed = df.select(
    col("id").alias("user_id"),
    from_json(col("purchase_history"), purchase_schema).alias("ph")
).select(
    col("user_id"),
    col("ph.payment_status").alias("payment_status"),
    col("ph.purchase_date").alias("purchase_date"),
    explode("ph.items").alias("item")
).select(
    col("user_id"),
    col("payment_status"),
    col("purchase_date"),
    col("item.id").cast("string").alias("item_id_str")
)

# 分区逻辑：根据 user_id 哈希取模
parsed = parsed.withColumn("partition_id", abs(hash(col("user_id"))) % args.num_partitions)
parsed = parsed.filter(col("partition_id") == args.partition_id)

# 映射子类 → 主类
categorized = parsed \
    .join(catalog_df, on="item_id_str", how="left") \
    .join(subcat_df, on="subcategory", how="left") \
    .filter(col("main_category").isNotNull())

# 构造事务
orders = categorized.withColumn("order_id", concat_ws("_", col("user_id"), col("purchase_date"))) \
    .groupBy("order_id") \
    .agg(collect_set("main_category").alias("categories")) \
    .filter(size(col("categories")) >= 1) \
    .select("categories")

# 保存到对应分区
output_path = f"E:/master/data_mining/频繁模式挖掘/退款模式分析/output/orders_part_{args.partition_id}"
orders.write.mode("overwrite").parquet(output_path)

print(f"✅ 分区 {args.partition_id} 完成，共保存 {orders.count()} 条事务")
spark.stop()