from pyspark.sql import SparkSession
from pyspark.sql.functions import col, concat_ws
from pyspark.ml.fpm import FPGrowth

# 初始化 Spark
spark = SparkSession.builder \
    .appName("Refund_FP_Growth_Training") \
    .config("spark.driver.memory", "24g") \
    .config("spark.executor.memory", "24g") \
    .config("spark.sql.shuffle.partitions", "200") \
    .getOrCreate()

spark.sparkContext.setLogLevel("ERROR")

# 读取所有分区生成的订单事务数据
orders = spark.read.parquet("E:/master/data_mining/频繁模式挖掘/退款模式分析/output/orders_part_*").cache()
print(f"合并后退款事务总数：{orders.count()}")

# 训练 FP-Growth 模型
fp_growth = FPGrowth(
    itemsCol="categories",
    minSupport=0.005,
    minConfidence=0.4,
    numPartitions=100
)
model = fp_growth.fit(orders)

# 提取关联规则
rules = model.associationRules.select(
    concat_ws(" + ", col("antecedent")).alias("前项"),
    concat_ws(" + ", col("consequent")).alias("后项"),
    col("confidence").alias("置信度"),
    col("lift").alias("提升度")
).orderBy(col("confidence").desc(), col("lift").desc())

# 显示前 100 条规则
print("\n=== 退款模式关联规则 Top 100 ===")
rules.show(100, truncate=False)

# 保存频繁项集和规则为 JSON（支持数组结构）
model.freqItemsets.write.mode("overwrite").json("E:/master/data_mining/频繁模式挖掘/退款模式分析/frequent_itemsets_json")
model.associationRules.write.mode("overwrite").json("E:/master/data_mining/频繁模式挖掘/退款模式分析/association_rules_json")

spark.stop()
