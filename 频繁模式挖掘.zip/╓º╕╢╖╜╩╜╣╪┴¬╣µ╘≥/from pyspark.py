from pyspark.sql import SparkSession
from pyspark.ml.fpm import FPGrowth
from pyspark.sql.functions import col, concat_ws, format_number

# 初始化 SparkSession
spark = SparkSession.builder \
    .appName("Train_FPGrowth_Payment_Category") \
    .config("spark.driver.memory", "16g") \
    .config("spark.executor.memory", "24g") \
    .getOrCreate()

spark.sparkContext.setLogLevel("ERROR")

# 加载所有事务分区数据
orders = spark.read.parquet("E:/master/data_mining/频繁模式挖掘/支付方式关联规则/output/payment_transactions_part_*").cache()

print(f"合并后事务总数：{orders.count()}")

# 训练 FP-Growth 模型
fp_growth = FPGrowth(
    itemsCol="items",
    minSupport=0.01,
    minConfidence=0.6
)
model = fp_growth.fit(orders)

# 提取关联规则
rules = model.associationRules.select(
    concat_ws(" + ", col("antecedent")).alias("前项"),
    concat_ws(" + ", col("consequent")).alias("后项"),
    format_number("confidence", 3).alias("置信度"),
    format_number("lift", 3).alias("提升度")
).orderBy(col("置信度").desc())

# 保存结果为 JSON
rules.write.mode("overwrite").json("E:/master/data_mining/频繁模式挖掘/支付方式关联规则/output/final_rules_json")
model.freqItemsets.write.mode("overwrite").json("E:/master/data_mining/频繁模式挖掘/支付方式关联规则/output/final_freq_items_json")

# 展示 Top N
print("\n=== 支付方式与商品主类关联规则 Top 50 ===")
rules.show(50, truncate=False)

spark.stop()
