import argparse
import json
from pyspark.sql import SparkSession
from pyspark.sql.functions import (
    col, from_json, explode, collect_set,
    year, quarter, month, dayofweek,
    lag, lead, hash, abs, concat_ws
)
from pyspark.sql.types import StructType, StructField, ArrayType, StringType, IntegerType, DoubleType
from pyspark.sql.window import Window

# 参数解析
parser = argparse.ArgumentParser()
parser.add_argument("--partition_id", type=int, required=True)
parser.add_argument("--num_partitions", type=int, default=6)
args = parser.parse_args()

# 初始化 Spark
spark = SparkSession.builder \
   .appName(f"TimeSeriesPatternMining_Part_{args.partition_id}") \
   .config("spark.driver.memory", "16g") \
   .config("spark.executor.memory", "24g") \
   .getOrCreate()
spark.sparkContext.setLogLevel("ERROR")

# 主类别映射
main_map = {
    "电子产品": ["智能手机", "笔记本电脑", "平板电脑", "智能手表", "耳机", "音响", "相机", "摄像机", "游戏机"],
    "服装": ["上衣", "裤子", "裙子", "内衣", "鞋子", "帽子", "手套", "围巾", "外套"],
    "食品": ["零食", "饮料", "调味品", "米面", "水产", "肉类", "蛋奶", "水果", "蔬菜"],
    "家居": ["家具", "床上用品", "厨具", "卫浴用品"],
    "办公": ["文具", "办公用品"],
    "运动户外": ["健身器材", "户外装备"],
    "玩具": ["玩具", "模型", "益智玩具"],
    "母婴": ["婴儿用品", "儿童课外读物"],
    "汽车用品": ["车载电子", "汽车装饰"]
}
sub2main = [(sub, main) for main, subs in main_map.items() for sub in subs]

# 商品目录加载与映射
with open("E:/master/data_mining/数据探索性分析与预处理/product_catalog.json", "r", encoding="utf-8") as f:
    catalog = {str(p["id"]): p["category"] for p in json.load(f)["products"]}
catalog_df = spark.createDataFrame([(k, v) for k, v in catalog.items()], ["item_id_str", "subcategory"])
subcat_df = spark.createDataFrame(sub2main, ["subcategory", "main_category"])

# JSON schema
purchase_schema = StructType([
    StructField("avg_price", DoubleType(), True),
    StructField("categories", StringType(), True),
    StructField("items", ArrayType(StructType([
        StructField("id", IntegerType(), True),
        StructField("count", IntegerType(), True),
        StructField("price", DoubleType(), True),
    ])), True),
    StructField("payment_method", StringType(), True),
    StructField("payment_status", StringType(), True),
    StructField("purchase_date", StringType(), True),
])

# 读取数据
df = spark.read.parquet("E:/master/data_mining/30G_data_new/30G_data_new")

# 解析 purchase_history
parsed = df.select(
    col("id").alias("user_id"),
    from_json(col("purchase_history"), purchase_schema).alias("ph")
).select(
    "user_id", "ph.purchase_date", explode("ph.items").alias("item")
).select(
    "user_id",
    "purchase_date",
    col("item.id").cast("string").alias("item_id_str")
)

# 分区
parsed = parsed.withColumn("partition_id", abs(hash(col("user_id"))) % args.num_partitions)
parsed = parsed.filter(col("partition_id") == args.partition_id)

# 类别映射
categorized = parsed \
   .join(catalog_df, on="item_id_str", how="left") \
   .join(subcat_df, on="subcategory", how="left") \
   .filter(col("main_category").isNotNull())

# 时间字段
categorized = categorized.withColumn("purchase_year", year(col("purchase_date")))
categorized = categorized.withColumn("purchase_month", month(col("purchase_date")))
categorized = categorized.withColumn("purchase_quarter", quarter(col("purchase_date")))

# ========== 月份频率 =============
category_seasonal_pattern_month = categorized.groupBy(
    "purchase_year", "purchase_month", "main_category"
).count().withColumnRenamed("count", "purchase_count")

# ========== 季度频率 =============
category_seasonal_pattern_quarter = categorized.groupBy(
    "purchase_year", "purchase_quarter", "main_category"
).count().withColumnRenamed("count", "purchase_count")

# ========== 先A后B的时序模式 ==========
windowSpec = Window.partitionBy("user_id").orderBy("purchase_date")
sorted_categorized = categorized \
    .withColumn("prev_category", lag("main_category", 1).over(windowSpec)) \
    .withColumn("next_category", lead("main_category", 1).over(windowSpec)) \
    .filter((col("prev_category").isNotNull()) & (col("next_category").isNotNull())) \
    .select("user_id", "purchase_date", "prev_category", "next_category")

# ========== 保存为 JSON ==========
output_path = "E:/master/data_mining/频繁模式挖掘/时间序列模式挖掘/output"

category_seasonal_pattern_month.write.mode("overwrite").json(f"{output_path}/category_seasonal_pattern_month_json")
category_seasonal_pattern_quarter.write.mode("overwrite").json(f"{output_path}/category_seasonal_pattern_quarter_json")
sorted_categorized.write.mode("overwrite").json(f"{output_path}/sequential_patterns_json")


spark.stop()
