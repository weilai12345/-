import argparse, json
from pyspark.sql import SparkSession
from pyspark.sql.functions import *
from pyspark.sql.types import StructType, StructField, IntegerType, StringType, ArrayType
from pyspark import SparkConf

parser = argparse.ArgumentParser()
parser.add_argument("--partition_id", type=int, required=True)
parser.add_argument("--num_partitions", type=int, default=6)
args = parser.parse_args()

# Spark 配置
spark_config = {
    "spark.driver.memory": "24g",
    "spark.executor.memory": "24g",
    "spark.sql.shuffle.partitions": "200",
    "spark.default.parallelism": "200",
    "spark.sql.adaptive.enabled": "true",
    "spark.sql.adaptive.skewJoin.enabled": "true",
    "spark.sql.execution.arrow.pyspark.enabled": "true",
    "spark.serializer": "org.apache.spark.serializer.KryoSerializer"
}

spark = SparkSession.builder \
    .appName(f"Generate_Transactions_{args.partition_id}") \
    .config(conf=SparkConf().setAll(spark_config.items())) \
    .getOrCreate()

spark.sparkContext.setLogLevel("ERROR")

# 主类映射
main_map = {
    "电子产品": ["智能手机","笔记本电脑","平板电脑","智能手表","耳机","音响","相机","摄像机","游戏机"],
    "服装": ["上衣","裤子","裙子","内衣","鞋子","帽子","手套","围巾","外套"],
    "食品": ["零食","饮料","调味品","米面","水产","肉类","蛋奶","水果","蔬菜"],
    "家居": ["家具","床上用品","厨具","卫浴用品"],
    "办公": ["文具","办公用品"],
    "运动户外": ["健身器材","户外装备"],
    "玩具": ["玩具","模型","益智玩具"],
    "母婴": ["婴儿用品","儿童课外读物"],
    "汽车用品": ["车载电子","汽车装饰"]
}
sub2main = [(sub, main) for main, subs in main_map.items() for sub in subs]

with open("E:/master/data_mining/数据探索性分析与预处理/product_catalog.json", encoding="utf-8") as f:
    catalog = {str(p["id"]): p["category"] for p in json.load(f)["products"]}

catalog_df = spark.createDataFrame([(str(pid), cat) for pid, cat in catalog.items()], ["item_id_str", "subcategory"])
subcat_df = spark.createDataFrame(sub2main, ["subcategory", "main_category"])

schema = StructType([
    StructField("purchase_date", StringType()),
    StructField("items", ArrayType(StructType([StructField("id", IntegerType())])))
])
raw_df = spark.read.parquet("E:/master/data_mining/30G_data_new/30G_data_new")

df = raw_df.select(
    col("id").alias("user_id"),
    from_json(col("purchase_history"), schema).alias("info")
).select(
    "user_id", explode("info.items").alias("item"), col("info.purchase_date").alias("purchase_date")
).select(
    "user_id", "purchase_date", col("item.id").alias("item_id")
).filter(col("item_id").isNotNull())

# 映射主类 + 添加分区标签
categorized = df.withColumn("item_id_str", col("item_id").cast("string")) \
    .join(broadcast(catalog_df), "item_id_str", "left") \
    .join(broadcast(subcat_df), "subcategory", "left") \
    .filter(col("main_category").isNotNull()) \
    .withColumn("partition_id", abs(hash(col("user_id"))) % args.num_partitions) \
    .filter(col("partition_id") == args.partition_id) \
    .cache()

orders = categorized.withColumn("order_id", sha2(concat_ws("_", col("user_id"), col("purchase_date")), 256)) \
    .groupBy("order_id") \
    .agg(collect_set("main_category").alias("categories")) \
    .filter(size("categories") > 1)

orders.write.mode("overwrite").parquet(f"output/orders_part_{args.partition_id}")
print(f"分区 {args.partition_id} 事务保存完成，共 {orders.count()} 条")
spark.stop()
