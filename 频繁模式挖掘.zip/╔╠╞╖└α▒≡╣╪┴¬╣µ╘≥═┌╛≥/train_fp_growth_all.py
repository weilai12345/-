from pyspark.sql import SparkSession
from pyspark.ml.fpm import FPGrowth
from pyspark.sql.functions import col, format_number, concat_ws

# 初始化 SparkSession
spark = SparkSession.builder \
    .appName("Train FPGrowth All - Full Rules") \
    .config("spark.driver.memory", "12g") \
    .config("spark.executor.memory", "12g") \
    .config("spark.driver.maxResultSize", "4g") \
    .getOrCreate()

spark.sparkContext.setLogLevel("ERROR")

# 加载合并后的事务数据
orders = spark.read.parquet("E:/master/data_mining/频繁模式挖掘/商品类别关联规则挖掘/output/orders_part_*")

print(f"合并后事务总数：{orders.count()}")

# 训练 FP-Growth 模型
fp_growth = FPGrowth(
    itemsCol="categories",
    minSupport=0.02,
    minConfidence=0.5
)
model = fp_growth.fit(orders)

# 输出全部关联规则（不筛选电子产品）
rules = model.associationRules.select(
    concat_ws(" + ", col("antecedent")).alias("前项"),
    concat_ws(" + ", col("consequent")).alias("后项"),
    format_number("confidence", 2).alias("置信度"),
    format_number("lift", 2).alias("提升度")
)
# 保存完整结果（为避免CSV不兼容array，推荐使用 JSON）
rules.write.mode("overwrite").json("output/all_rules_json")
model.freqItemsets.write.mode("overwrite").json("output/all_freq_items_json")

print("\n=== 所有满足支持度和置信度要求的规则 Top 20 ===")
rules.orderBy(col("置信度").desc()).show(20, truncate=False)



spark.stop()

